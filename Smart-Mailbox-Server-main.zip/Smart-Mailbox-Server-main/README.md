# Smart-Mailbox
Senior design project for spring 2022
Anti-Porch Pirate
Created by Jacob, Carter, Sam, and James


Main project created

Start in the project directory Smart-Mailbox-Server

To run:

Use pip to get requirements.txt

Terminal Commands

cd smartMailbox

python3 manage.py makemigrations storage

python3 manage.py migrate

python3 manage.py runserver

go to 127.0.0.1:8000 in a browser
